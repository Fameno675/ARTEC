from django.apps import AppConfig


class DashboardConfig(AppConfig):
    name = "apps.dashboard"
    verbose_name = "Tableaux de bord"
