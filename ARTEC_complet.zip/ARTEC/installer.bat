@echo off
REM Installation ARTEC (Windows). Double-cliquer ou lancer depuis cmd dans ce dossier.
cd /d "%~dp0"
where py >nul 2>nul || (echo Python 3.11+ introuvable. Installez-le depuis python.org puis relancez. & pause & exit /b 1)
if not exist .venv ( py -3 -m venv .venv || (echo Echec de creation de l'environnement. & pause & exit /b 1) )
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt || (echo Echec d'installation des dependances. Essayez : pip install -r requirements-lock.txt & pause & exit /b 1)
if not exist .env (
  copy .env.example .env >nul
  for /f %%k in ('python -c "import secrets; print(secrets.token_urlsafe(60))"') do powershell -Command "(Get-Content .env) -replace 'remplacez-par-une-longue-valeur-aleatoire','%%k' | Set-Content .env"
  echo.
  echo >>> Le fichier .env vient d'etre cree. Ouvrez-le et renseignez DB_PASSWORD (le mot de passe du role PostgreSQL "artec").
  echo >>> Creez le role et la base avec scripts\creer_base.sql (voir docs\INSTALL_WINDOWS.md, etape 2), puis relancez ce script.
  notepad .env
  pause & exit /b 0
)
python manage.py check || (pause & exit /b 1)
python manage.py migrate || (echo Migration impossible : verifiez PostgreSQL et le fichier .env. & pause & exit /b 1)
echo.
echo Installation terminee.
echo   - Donnees de demonstration (facultatif) : demo.bat
echo   - Lancer le site                        : lancer.bat
pause
